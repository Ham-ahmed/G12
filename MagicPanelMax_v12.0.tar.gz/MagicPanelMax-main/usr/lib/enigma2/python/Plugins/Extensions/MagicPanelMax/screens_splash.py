# -*- coding: utf-8 -*-
"""Reliable Splash screen for Enigma2 plugins.

Required assets:
    <plugin_directory>/backg/splash_bground.png
    <plugin_directory>/backg/splash_start.png

Optional assets:
    <plugin_directory>/backg/splash_track.png
    <plugin_directory>/backg/splash_glow.png
"""

from . import _
import os
import re
import threading

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from enigma import eTimer, ePoint, getDesktop

from .storage import load_theme, THEMES
from .log import optional_failure


FirstRunWizardScreen = None
PortalListScreen = None
WIZARD_DONE_FILE = ""
_schedule_startup_cache_maintenance = None
restore_plugin_service = None

# This file is SplashScreen_debug.py inside the plugin package.
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(PLUGIN_DIR, "backg")
DEBUG_LOG = "/tmp/magic_panel_splash.log"

def _debug(message):
    try:
        with open(DEBUG_LOG, "a") as log:
            log.write("[Splash] %s\n" % message)
    except Exception:
        pass
    print("[Splash] %s" % message)

_ACTIVE_THEME_CACHE = None
_ACTIVE_THEME_LOCK = threading.RLock()


# -----------------------------------------------------------------------------
# Asset handling
# -----------------------------------------------------------------------------
def _active_theme():
    global _ACTIVE_THEME_CACHE
    with _ACTIVE_THEME_LOCK:
        if _ACTIVE_THEME_CACHE in THEMES:
            return _ACTIVE_THEME_CACHE
        try:
            value = load_theme(readonly=True)
        except Exception:
            value = "nova_fhd"
        _ACTIVE_THEME_CACHE = value if value in THEMES else "nova_fhd"
        return _ACTIVE_THEME_CACHE


def _candidates(filename):
    """Return only paths for the requested filename, in priority order."""
    theme = _active_theme()
    paths = [
        os.path.join(ASSET_DIR, "themes", theme, filename),
        os.path.join(ASSET_DIR, "themes", "nova_fhd", filename),
        os.path.join(ASSET_DIR, filename),
        os.path.join(PLUGIN_DIR, filename),
        os.path.join(PLUGIN_DIR, "images", filename),
        os.path.join(PLUGIN_DIR, "res", filename),
        os.path.join(PLUGIN_DIR, "skin", filename),
    ]
    # Also find the file if the installer placed it in another subfolder.
    try:
        for root, dirs, files in os.walk(PLUGIN_DIR):
            if filename in files:
                paths.append(os.path.join(root, filename))
    except Exception:
        pass
    result = []
    for path in paths:
        if path not in result:
            result.append(path)
    return tuple(result)


def asset(filename):
    """Return an existing asset path, or the normal path if it is missing."""
    for path in _candidates(filename):
        if os.path.isfile(path):
            return path
    return os.path.join(ASSET_DIR, filename)


def _scale_skin(xml):
    """Scale the 1920x1080 skin for the actual framebuffer."""
    try:
        size = getDesktop(0).size()
        width, height = int(size.width()), int(size.height())
    except Exception:
        return xml

    if width == 1920 and height == 1080:
        return xml

    sx = width / 1920.0
    sy = height / 1080.0

    def pair(match):
        return '%s="%d,%d"' % (
            match.group(1),
            round(int(match.group(2)) * sx),
            round(int(match.group(3)) * sy),
        )

    xml = re.sub(r'(position|size)="(\d+),(\d+)"', pair, xml)
    xml = re.sub(
        r'font="([^;]+);(\d+)"',
        lambda m: 'font="%s;%d"' % (
            m.group(1), max(14, round(int(m.group(2)) * sy))
        ),
        xml,
    )
    return xml


def configure_splash_screen(
    first_run_wizard_screen,
    portal_list_screen,
    wizard_done_file,
    scale_skin=None,
    schedule_startup_cache_maintenance=None,
    asset_func=None,
    restore_plugin_service_func=None,
):
    """Connect the splash screen to the rest of the plugin."""
    global FirstRunWizardScreen, PortalListScreen, WIZARD_DONE_FILE
    global _schedule_startup_cache_maintenance, restore_plugin_service

    FirstRunWizardScreen = first_run_wizard_screen
    PortalListScreen = portal_list_screen
    WIZARD_DONE_FILE = wizard_done_file or ""
    _schedule_startup_cache_maintenance = schedule_startup_cache_maintenance
    restore_plugin_service = restore_plugin_service_func


_BAR_X, _BAR_W = 190, 748
_GLOW_W, _GLOW_Y = 86, 405


class SplashScreen(Screen):
    """Splash screen that loads PNG files only after widgets exist."""

    skin = _scale_skin("""<screen name="SplashScreen" position="350,190" size="1100,618" backgroundColor="#01040a" flags="wfNoBorder">
  <widget name="bg" position="0,0" size="1100,618" alphatest="blend" zPosition="1" />
  <widget name="logo" position="254,89" size="600,240" alphatest="blend" transparent="1" zPosition="5" />
  <widget name="status" position="110,353" size="900,42" font="Regular;24" halign="center" valign="center" foregroundColor="#d5e4ee" backgroundColor="#01040a" transparent="1" zPosition="10" />
  <ePixmap position="182,415" size="760,14" pixmap="%s" alphatest="blend" zPosition="6" />
  <widget name="progress" position="190,419" size="748,4" borderWidth="0" backgroundColor="#0b1a27" foregroundColor="#6fd8ff" zPosition="7" />
  <widget name="progress_glow" position="170,405" size="86,42" alphatest="blend" transparent="1" zPosition="9" />
  <widget name="edition" position="304,471" size="500,30" font="Regular;17" halign="center" valign="center" foregroundColor="#66859a" backgroundColor="#01040a" transparent="1" zPosition="10" />
  <widget name="version" position="304,502" size="500,25" font="Regular;14" halign="center" valign="center" foregroundColor="#4a6a7a" backgroundColor="#01040a" transparent="1" zPosition="10" />
  <eLabel position="409,441" size="300,25" background="#66859a" halign="center" valign="center" transparent="0" cornerRadius="26" font="Regular;20" zPosition="10" text="Designed By Hamdy Ahmed" />
</screen>""" % asset("splash_track.png"))

    def __init__(self, session):
        Screen.__init__(self, session)

        # These names exactly match every widget in skin above.
        self["bg"] = Pixmap()
        self["logo"] = Pixmap()
        self["status"] = Label(_("Loading Magic Panel Max..."))
        self["edition"] = Label("MAGIC Panel  •  MAX")
        self["version"] = Label(self._plugin_version())
        self["progress"] = ProgressBar()
        self["progress"].setRange((0, 100))
        self["progress"].setValue(8)
        self["progress_glow"] = Pixmap()

        self._stage = 0
        self._runtime_loaded = False
        self._timer = eTimer()
        self._timer_connection = None

        try:
            self._timer_connection = self._timer.timeout.connect(self._go)
        except Exception:
            try:
                self._timer.callback.append(self._go)
            except Exception as exc:
                optional_failure("ui.splash_timer", exc)

        self.onLayoutFinish.append(self._load_images)
        self.onLayoutFinish.append(self._start_splash_timer)
        self.onClose.append(self._stop)
        self.onClose.append(self._safe_restore_service)

    @staticmethod
    def _plugin_version():
        try:
            from . import __version__
            return "v%s" % __version__
        except Exception:
            return ""

    def _load_one(self, widget_name, filename, required=False):
        """Load a PNG after layout using the Enigma2 method available on the image."""
        widget = self[widget_name]
        instance = getattr(widget, "instance", None)
        candidates = _candidates(filename)
        _debug("plugin_dir=%s" % PLUGIN_DIR)
        _debug("looking for %s in: %s" % (filename, " | ".join(candidates)))
        if instance is None:
            _debug("widget %s has no instance" % widget_name)
            return False

        for path in candidates:
            if not os.path.isfile(path):
                continue
            try:
                size = os.path.getsize(path)
                _debug("found %s size=%d" % (path, size))
                loaded = False
                # Direct gPixmap loading is the most reliable method on Enigma2.
                try:
                    from enigma import loadPNG
                    pixmap = loadPNG(path)
                    if pixmap is not None:
                        instance.setPixmap(pixmap)
                        loaded = True
                except Exception as direct_error:
                    _debug("loadPNG failed: %s" % direct_error)
                # Fallback for images where the platform only exposes this API.
                if not loaded:
                    setter = getattr(instance, "setPixmapFromFile", None)
                    if callable(setter):
                        result = setter(path)
                        loaded = result is not False
                if not loaded:
                    raise RuntimeError("both PNG loading methods failed")
                invalidate = getattr(instance, "invalidate", None)
                if callable(invalidate):
                    invalidate()
                widget.show()
                _debug("loaded %s from %s" % (filename, path))
                return True
            except Exception as exc:
                _debug("load failed %s: %s" % (path, exc))
                optional_failure("ui.splash_%s" % widget_name, exc)

        message = "missing %s; searched: %s" % (filename, " | ".join(candidates))
        _debug(message)
        if required:
            self["status"].setText(_("Splash image not found: %s") % filename)
        return False

    def _load_images(self):
        # The two requested images are loaded here, after layout is ready.
        self._load_one("bg", "splash_bground.png", required=True)
        self._load_one("logo", "splash_start.png", required=True)
        self._load_one("progress_glow", "splash_glow.png")

    def _safe_restore_service(self):
        try:
            if callable(restore_plugin_service):
                restore_plugin_service(self.session)
        except Exception as exc:
            optional_failure("ui.splash_restore", exc)

    def _ensure_runtime(self):
        if self._runtime_loaded and PortalListScreen is not None:
            return True
        try:
            from . import ui as runtime_ui
            try:
                runtime_ui.begin_plugin_launch(self.session)
            except Exception as exc:
                optional_failure("ui.splash_begin_launch", exc)
            self._runtime_loaded = PortalListScreen is not None
            if self._runtime_loaded and callable(_schedule_startup_cache_maintenance):
                try:
                    _schedule_startup_cache_maintenance()
                except Exception as exc:
                    optional_failure("ui.splash_maintenance_schedule", exc)
            return self._runtime_loaded
        except Exception as exc:
            optional_failure("ui.splash_lazy_runtime", exc)
            self["status"].setText(_("Magic Panel failed to initialize"))
            return False

    def _start_splash_timer(self):
        self._set_splash_progress(8)
        try:
            self._timer.start(20, True)
        except Exception:
            self._go()

    def _set_splash_progress(self, percent):
        percent = max(0, min(100, int(percent)))
        try:
            self["progress"].setValue(percent)
            size = getDesktop(0).size()
            sx = float(size.width()) / 1920.0
            sy = float(size.height()) / 1080.0
            x = _BAR_X + int(round((_BAR_W * percent) / 100.0)) - _GLOW_W // 2
            x = max(_BAR_X - _GLOW_W // 2, min(_BAR_X + _BAR_W - _GLOW_W // 2, x))
            instance = self["progress_glow"].instance
            if instance is not None:
                instance.move(ePoint(round(x * sx), round(_GLOW_Y * sy)))
        except Exception as exc:
            optional_failure("ui.splash_progress", exc)

    def _step(self, stage, text, percent, delay):
        self._stage = stage
        self["status"].setText(text)
        self._set_splash_progress(percent)
        try:
            self._timer.start(delay, True)
        except Exception:
            self._go()

    def _go(self):
        if self._stage == 0:
            return self._step(1, _("Preparing interface"), 24, 150)
        if self._stage == 1:
            return self._step(2, _("Loading Magic Panel"), 46, 150)
        if self._stage == 2:
            self._stage = 3
            if not self._ensure_runtime():
                self._set_splash_progress(100)
                try:
                    self._timer.start(1200, True)
                except Exception:
                    self.close()
                return
            self["status"].setText(_("Preparing your library"))
            self._set_splash_progress(88)
            try:
                self._timer.start(20, True)
            except Exception:
                self._go()
            return
        if self._stage == 3:
            return self._step(4, _("Ready"), 100, 250)
        if not self._runtime_loaded or PortalListScreen is None:
            self.close()
            return
        self._stop()
        try:
            self.session.openWithCallback(self._next_screen_closed, PortalListScreen)
        except Exception as exc:
            optional_failure("ui.splash_open_portal", exc)
            self.close()

    def _next_screen_closed(self, *args, **kwargs):
        self.close()

    def _stop(self):
        try:
            self._timer.stop()
        except Exception:
            pass
        try:
            if self._timer_connection is not None:
                self._timer_connection.disconnect()
        except Exception:
            pass
        try:
            callback = getattr(self._timer, "callback", [])
            while self._go in callback:
                callback.remove(self._go)
        except Exception:
            pass
